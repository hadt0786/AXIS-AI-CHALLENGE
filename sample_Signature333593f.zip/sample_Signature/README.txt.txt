FILE STRUCTURE:
1.genuines : genuine signatures of 30 people, 5 sample each.
2.forged : forged signature of the same 30 people as in genuine folder, 5 sample each.

Naming of files : NFI-XXXYYZZZ
explaination    XXX - ID number of a person who has done the signature. 
		YY - Image smaple number.
		ZZZ - ID number of person whose signature is in photo. 

for example: NFI-00602023 is an image of signature of person number 023 done by person 006. This is a forged signature.
	     NFI-02103021 is an image of signature of person number 021 done by person 021. This is a genuine signature.   